﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generice
{
    struct Point<T> where T:struct
    {
        /// <summary>Initializes a new instance of the <see cref="Point{T}" /> struct.</summary>
        /// <param name="x">The x.</param>
        /// <param name="y">The y.</param>
        public Point(T x, T y)
        {
            X = x;
            Y = y;
        }

        /// <summary>Gets the x.</summary>
        /// <value>The x.</value>
        public T X { get; private set; }
        public T Y { get; private set; }

        public override string ToString()
        {
            return $"X={X}, Y={Y}";
        }

        /// <summary>Resets this instance.</summary>
        /// <exception cref="Exception"></exception>
        public void Reset()
        {
            X = default(T);
            Y = default(T);
            throw new Exception();
        }
    }
}
