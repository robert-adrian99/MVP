﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generice
{
    class Program
    {
        static void Main(string[] args)
        {
            //int a = 3, b = 4;
            //string s1 = "abc", s2 = "altceva";

            //Swap(ref a, ref b);
            //Console.WriteLine($"a={a}, b={b}");

            //Swap(ref s1, ref s2);
            //Console.WriteLine($"s1={s1}, s2={s2}");

            Point<int> p = new Point<int>(3, 30);
            Console.WriteLine($"p={p}");
            p.Reset();
            Console.WriteLine($"p={p}");
        }

        static void Swap<T>(ref T a, ref T b)
        {
            T aux = a;
            a = b;
            b = aux;
        }
    }
}
