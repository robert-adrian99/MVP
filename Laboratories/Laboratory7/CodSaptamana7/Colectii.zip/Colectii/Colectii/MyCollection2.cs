﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Colectii
{
    class MyCollection2 : IEnumerable
    {
        private int[] contents = { 1, 2, 3, 4, 5, 6 };

        public IEnumerator GetEnumerator()
        {
            foreach(int x in contents)
            {
                yield return x;
            }
        }
    }
}
