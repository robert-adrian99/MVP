﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Colectii
{
    class Program
    {
        static void Main(string[] args)
        {
            MyCollection2 col = new MyCollection2();

            foreach (int value in col)
            {
                Console.WriteLine(value);
            }

            //foreach (var item in GetSquares(10))
            //{
            //    Console.WriteLine(item);
            //}
        }

        static IEnumerable GetSquares(int n)
        {
            for(int i=0; i<n; i++)
            {
                yield return i*i;
            }
        }
    }
}
