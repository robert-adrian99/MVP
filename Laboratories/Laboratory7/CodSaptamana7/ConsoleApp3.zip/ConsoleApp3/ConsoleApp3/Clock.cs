﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class Clock
    {
        public event SecondChangeHandler OnSecondChange;

        public void Run()
        {
            Console.WriteLine("Inainte de F1");
            F1();
            Console.WriteLine("Dupa F1");
        }

        /// <summary>F1s this instance.</summary>
        /// <exception cref="NotImplementedException"></exception>
        private void F1()
        {
            throw new NotImplementedException();
        }
    }
}
