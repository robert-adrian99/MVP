﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class ConsoleTimeWriter
    {
        /// <summary>Writes to console.</summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="TimeInfoEventArgs" /> instance containing the event data.</param>
        public void WriteToConsole(object sender, TimeInfoEventArgs e)
        {
            Console.WriteLine($"From ConsoleTimeWriter: {e.Hour}:{e.Minute}:{e.Second}");
        }

        public void Subscribe(Clock clock)
        {
            clock.OnSecondChange += WriteToConsole;
        }
    }
}
