﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inainte de F1");
            F1();
            Console.WriteLine("Dupa F1");
        }

        private static void F1()
        {
            Console.WriteLine("La intrare in F1");
            try
            {
                F2();
            }
            catch
            {
                //Console.WriteLine($"Mesaj de la exceptie: {e.Message}");
                //log
            }
            finally
            {
                Console.WriteLine("Asta se executa intotdeauna");
            }
            Console.WriteLine("la iesire din F1");
        }

        /// <summary>F2s this instance.</summary>
        /// <exception cref="Exception">demo</exception>
        private static void F2()
        {
            Console.WriteLine("La intrare in F2");
            throw new Exception("demo");
            Console.WriteLine("La iesire din F2");
        }
    }
}
