﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class FileTimeWriter
    {
        public void WriteToFile(object sender, TimeInfoEventArgs e)
        {
            Console.WriteLine($"From FileTimeWriter: {e.Hour}:{e.Minute}:{e.Second}");
        }

        public void Subscribe(Clock clock)
        {
            clock.OnSecondChange += WriteToFile;
        }
    }
}
