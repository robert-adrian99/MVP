﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Colectie
{
    class MyCollection2 : IEnumerable
    {
        private int[] contents = { 1, 2, 3, 4, 5 };

        public IEnumerator GetEnumerator()
        {
            for (int i=0; i<contents.Length; i++)
            {
                yield return contents[i];
            }
        }
    }
}
