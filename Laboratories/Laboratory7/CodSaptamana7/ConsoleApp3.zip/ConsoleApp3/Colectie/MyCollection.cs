﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Colectie
{
    public class MyCollection : IEnumerable
    {
        private int[] contents = { 1, 2, 3, 4, 5 };

        public IEnumerator GetEnumerator()
        {
            return new MyEnumerator(this);
        }

        private class MyEnumerator : IEnumerator
        {
            private MyCollection myCollection;
            int index = -1;

            public MyEnumerator(MyCollection myCollection)
            {
                this.myCollection = myCollection;
            }

            public object Current
            {
                get
                {
                    return myCollection.contents[index];
                }
            }

            public bool MoveNext()
            {
                if (index < myCollection.contents.Length-1)
                {
                    index++;
                    return true;
                }
                return false;
            }

            public void Reset()
            {
                index = -1;
            }
        }
    }
}
