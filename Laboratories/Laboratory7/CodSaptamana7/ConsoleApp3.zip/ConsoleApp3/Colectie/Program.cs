﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Colectie
{
    class Program
    {
        static void Main(string[] args)
        {
            //MyCollection2 myCollection = new MyCollection2();
            //foreach (int item in myCollection)
            //{
            //    Console.WriteLine(item);
            //}

            //foreach (int item in GetValues())
            //{
            //    Console.WriteLine(item);
            //}

            //int x = 3, y = 4;
            //string a = "ceva", b = "altceva";

            //SwapValue<int>(ref x, ref y);
            //Console.WriteLine($"x={x}, y={y}"); ;
            //SwapValue<string>(ref a, ref b);
            //Console.WriteLine($"a={a}, b={b}"); ;

            Point<int> p1 = new Point<int>(10, 20);
            Console.WriteLine(p1);
            p1.Reset();
            Console.WriteLine(p1);
        }

        static void SwapValue<T>(ref T a, ref T b)
        {
            T aux = a;
            a = b;
            b = aux;
        }

        //private static IEnumerable GetValues()
        //{
        //    Console.WriteLine("voi returna 1");
        //    yield return 1;
        //    Console.WriteLine("voi returna 2");
        //    yield return 2;
        //    Console.WriteLine("voi returna 3");
        //    yield return 3;
        //}

    }
}
