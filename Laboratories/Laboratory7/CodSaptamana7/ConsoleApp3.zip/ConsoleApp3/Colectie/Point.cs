﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Colectie
{
    class Point<T>
    {
        public Point(T x, T y)
        {
            X = x;
            Y = y;
        }

        public void Reset()
        {
            X = default(T);
            Y = default(T);
        }

        //public void Shift(T deltaX, T deltaY)
        //{
        //    X = X + deltaX;
        //}

        public override string ToString()
        {
            return X.ToString() + "," + Y.ToString();
        }

        public T X { get; private set; }
        public T Y { get; private set; }
    }
}
